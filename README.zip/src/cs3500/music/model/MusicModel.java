package cs3500.music.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * A model designed to represent a song.
 */
public class MusicModel implements IMusicModel {

  public List<Note> notes;

  /**
   * A basic constructor for MusicModel.
   */
  public MusicModel() {
    this.notes = new ArrayList<Note>();
  }

  @Override
  public void addNote(Note n) {
    notes.add(n);
    Collections.sort(this.notes);
  }

  @Override
  public void addBeat(NoteName name, int octave, int start, int duration) {

    String note = name.asString() + Integer.toString(octave);

    for (Note n : this.notes) {
      if (n.toString().equals(note)) {
        n.addBeat(start, duration);
        return;
      }
    }

    Note n1 = new Note(name, octave);
    n1.addBeat(start, duration);
    this.addNote(n1);
    Collections.sort(this.notes);
  }

  @Override
  public void removeBeat(NoteName name, int octave, int start) {
    String note = name.asString() + Integer.toString(octave);

    for (Note n : this.notes) {
      if (n.toString().equals(note)) {
        n.removeBeat(start);
      }
    }
  }

  @Override
  public String print() {
    String result = "";

    int lines = 0;
    for (Note n : this.notes) {
      if (n.beats.size() > lines) {
        lines = n.beats.size();
      }
    }
    int length = Integer.toString(lines).length();
    String pad = "%" + Integer.toString(length) + "d";

    for (int i = length; i > 0; i--) {
      result += " ";
    }

    for (Note n : this.notes) {
      switch (n.toString().length()) {
        case 2 : result += "  " + n.toString() + " ";
          break;
        case 3 : result += " " + n.toString() + " ";
          break;
        case 4 : result += " " + n.toString();
          break;
        case 5 : result += n.toString();
          break;
        default : throw new IllegalArgumentException("this.notes malformed");
      }
    }

    result += "\n";

    for (int i = 0; i < lines; i++) {
      result += String.format(pad, i);
      for (Note n : this.notes) {
        result += n.print(i);
      }
      result += "\n";
    }
    return result;
  }

}

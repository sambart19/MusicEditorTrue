package cs3500.music.model;

/**
 * An interface to represent a model of music.
 */
public interface IMusicModel {

  /**
   * Allows the user to add notes directly, rather than individual beats.
   * @param n = The note to be added.
   */
  void addNote(Note n);

  /**
   * Used to add a beat to the given note. If the note is not already in this model, add it.
   * @param name = The name of the note do alter / add.
   * @param octave = The octave of the note to alter / add.
   * @param start = The beat to start on.
   * @param duration = The duration of the note.
   */
  void addBeat(NoteName name, int octave, int start, int duration);

  /**
   * Allows the user to remove beats from this model. Does not resize the containers.
   * @param name = Name of the note to remove a beat from.
   * @param octave = Octave to remove the beat from
   * @param start = Location of the head of the beat to remove.
   */
  void removeBeat(NoteName name, int octave, int start);

  /**
   * Displays the model. The head of each note is represented as "  X  ", the tail
   * is represented as "  |  ", and a spot with no note is represented as "     ".
   * @return The string that represents this model.
   */
  String print();
}

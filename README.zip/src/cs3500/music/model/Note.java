package cs3500.music.model;

import java.util.ArrayList;

/**
 * Designed to represent a note with octave included.
 */
public class Note implements Comparable<Note> {

  public NoteName name;
  public int octave;
  public ArrayList<String> beats;

  /**
   * Basic constructor for a note.
   * @param name The NoteName of this note.
   * @param octave The octave number of this note.
   */
  public Note(NoteName name, int octave) {
    if (name == null) {
      throw new IllegalArgumentException("name cannot be null");
    }
    this.name = name;
    this.octave = octave;
    this.beats = new ArrayList<String>();
  }

  /**
   * Adds a series of beats to this list of beats. It extends the list to fit the new beat given,
   * adding an "  X  " as the "head" of the note and "  |  " for the rest of the duration given.
   * Throws an IllegalArgumentException if the start index is less than 0.
   * @param start The beat to start the note on.
   * @param duration How long the beat should last.
   */
  public void addBeat(int start, int duration) {

    if (start < 0) {
      throw new IllegalArgumentException("start index out of range");
    }

    if (duration < 1) {
      throw new IllegalArgumentException("duration cannot be less than one");
    }

    while (start >= this.beats.size()) {
      this.beats.add("     ");
    }

    this.beats.set(start, "  X  ");
    int count = 1;

    while (duration > 1) {
      if (start + count >= this.beats.size()) {
        this.beats.add("     ");
      }
      this.beats.set(start + count, "  |  ");
      count++;
      duration--;
    }

  }

  /**
   * Removes a series of beats starting from the given index of the head to the end of the tail.
   * Does not resize the array. Throws an IllegalArgumentException if the given start is out of
   * range or if the start is not the head of a note.
   * @param start = The index of the note to be removed.
   */
  public void removeBeat(int start) {
    if (start < 0 || start >= this.beats.size()) {
      throw new IllegalArgumentException("start index out of range");
    }

    if (!(this.beats.get(start).equals("  X  "))) {
      throw new IllegalArgumentException("index not at the start of a note");
    }

    this.beats.set(start, "     ");

    int count = 1;
    while (start + count < this.beats.size() && this.print(start + count).equals("  |  ")) {
      this.beats.set(start + count, "     ");
      count++;
    }
  }

  /**
   * Converts this note to a string.
   * @return This note as a string.
   */
  public String toString() {
    return name.asString() + Integer.toString(octave);
  }

  /**
   * Used to print a single beat of this.
   * @param line = beat to be printed.
   * @return The beat given, if out of range return "     ".
   */
  public String print(int line) {
    if (line >= this.beats.size()) {
      return "     ";
    } else {
      return this.beats.get(line);
    }
  }

  /**
   * Used to compare notes. Returns negative if that is greater than this.
   * @param that = note to compare to this note.
   * @return The difference between the notes.
   */
  public int compareTo(Note that) {
    if (this.octave != that.octave) {
      return this.octave - that.octave;
    } else {
      return this.name.ordinal() - that.name.ordinal();
    }
  }

}
